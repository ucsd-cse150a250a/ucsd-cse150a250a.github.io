import math
import numpy as np
import matplotlib.pyplot as plt
from typing import Tuple

def load_data(relative_bigram_path: str, relative_unigram_path: str, relative_vocab_path: str) -> Tuple[dict, dict]:
    """
    TODO: Load and process the bigram, unigram, and vocabulary data from files.

    IMPORTANT: Use relative paths only! Do NOT use absolute paths as this may cause 
    the autograder to fail when running tests.

    This function should:
    1. Read bigram data from relative_bigram_path (format: "word1_index word2_index count" per line)
    2. Read unigram counts from relative_unigram_path (format: one count per line)
    3. Read vocabulary from relative_vocab_path (format: one word per line)
    4. Build a unigram_dict mapping word -> count
    5. Build a bigram_dict mapping word1 -> {word2: count}

    Note: In bigram file, indices are 1-based (not 0-based).
    Note: Only include bigrams where the first word actually has successors.

    Parameters
    ----------
    relative_bigram_path : str
        Relative path to bigram counts file (e.g., 'bigram.txt').
    relative_unigram_path : str
        Relative path to unigram counts file (e.g., 'unigram.txt').
    relative_vocab_path : str
        Relative path to vocabulary file (e.g., 'vocab.txt').

    Returns
    -------
    Tuple[dict, dict]
        A tuple containing (bigram_dict, unigram_dict).
        - bigram_dict: dict[str, dict[str, int]] - nested dictionary of bigram counts
        - unigram_dict: dict[str, int] - dictionary of unigram counts
    """
    raise NotImplementedError("load_data function is not implemented.")

def compute_unigram_probabilities(unigram_dict: dict[str, int]) -> dict[str, float]:
    """
    TODO: Compute maximum likelihood unigram probabilities P(w) for each word.

    Parameters
    ----------
    unigram_dict : dict[str, int]
        Dictionary mapping words to their counts.

    Returns
    -------
    dict[str, float]
        Dictionary mapping words to their unigram probabilities.
    """
    raise NotImplementedError("compute_unigram_probabilities function is not implemented.")

def compute_bigram_probabilities(bigram_dict: dict[str, dict[str, int]]) -> dict[str, dict[str, float]]:
    """
    TODO: Compute maximum likelihood bigram probabilities P(w'|w) for each word pair.

    Parameters
    ----------
    bigram_dict : dict[str, dict[str, int]]
        Nested dictionary of bigram counts.

    Returns
    -------
    dict[str, dict[str, float]]
        Nested dictionary mapping word1 -> {word2: probability}.
    """
    raise NotImplementedError("compute_bigram_probabilities function is not implemented.")

def compute_sentence_log_likelihood(
    sentence: str,
    unigram_probabilities: dict[str, float],
    bigram_probabilities: dict[str, dict[str, float]]
) -> Tuple[float, float]:
    """
    TODO: Compute the log-likelihood of a sentence under both unigram and bigram models.

    Note:
    - Use <s> as the sentence start token for the first word's bigram probability
    - If a word is not in vocabulary, replace it with <UNK>
    - If a bigram is not observed, set bigram log-likelihood to -infinity

    Parameters
    ----------
    sentence : str
        Input sentence (space-separated words).
    unigram_probabilities : dict[str, float]
        Unigram probabilities.
    bigram_probabilities : dict[str, dict[str, float]]
        Bigram probabilities.

    Returns
    -------
    Tuple[float, float]
        A tuple containing (unigram_log_likelihood, bigram_log_likelihood).
    """
    raise NotImplementedError("compute_sentence_log_likelihood function is not implemented.")

def compute_mixed_likelihood(
    sentence: str,
    lambda_val: float,
    unigram_probabilities: dict[str, float],
    bigram_probabilities: dict[str, dict[str, float]]
) -> float:
    """
    TODO: Compute the log-likelihood under a mixed/interpolated model.

    Note:
    - Use <s> as the previous token for the first word
    - If a word is not in vocabulary, replace it with <UNK>
    - If a bigram is not observed, use 0 for P_b(w'|w)
    - If the mixed probability is 0, return -infinity

    Parameters
    ----------
    sentence : str
        Input sentence (space-separated words).
    lambda_val : float
        Interpolation weight for unigram model (between 0 and 1).
    unigram_probabilities : dict[str, float]
        Unigram probabilities.
    bigram_probabilities : dict[str, dict[str, float]]
        Bigram probabilities.

    Returns
    -------
    float
        Mixed model log-likelihood.
    """
    raise NotImplementedError("compute_mixed_likelihood function is not implemented.")

def plot_and_get_optimal_lambda(
    sentence: str,
    unigram_probabilities: dict[str, float],
    bigram_probabilities: dict[str, dict[str, float]]
) -> float:
    """
    TODO: Find the optimal lambda value that maximizes the mixed model likelihood.

    This function should:
    1. Try lambda values from 0.00, 0.01, 0.02, ..., 0.99, 1.00
    2. For each lambda, compute the mixed likelihood
    3. Find the lambda that gives the maximum likelihood
    4. Optionally: plot likelihood vs lambda (not required for autograder)

    Parameters
    ----------
    sentence : str
        Input sentence (space-separated words).
    unigram_probabilities : dict[str, float]
        Unigram probabilities.
    bigram_probabilities : dict[str, dict[str, float]]
        Bigram probabilities.

    Returns
    -------
    float
        Optimal lambda value (between 0 and 1).
    """
    raise NotImplementedError("plot_and_get_optimal_lambda function is not implemented.")

if __name__ == "__main__":
    # You can test your functions here
    # Example usage:
    relative_bigram_path = 'bigram.txt'
    relative_unigram_path = 'unigram.txt'
    relative_vocab_path = 'vocab.txt'

    # Load data
    # bigram_dict, unigram_dict = load_data(relative_bigram_path, relative_unigram_path, relative_vocab_path)

    # Compute probabilities
    # unigram_probs = compute_unigram_probabilities(unigram_dict)
    # bigram_probs = compute_bigram_probabilities(bigram_dict)

    # Test on example sentence
    # sentence = "THE STOCK MARKET FELL BY ONE HUNDRED POINTS LAST WEEK"
    # u_ll, b_ll = compute_sentence_log_likelihood(sentence, unigram_probs, bigram_probs)
    # print(f"Unigram log-likelihood: {u_ll}")
    # print(f"Bigram log-likelihood: {b_ll}")

    pass
