import pandas as pd
from pathlib import Path
from tqdm import tqdm
from tabulate import tabulate
from typing import Tuple

def check_evidence(evidence: Tuple[str, str], w: str) -> bool:
    """
    TODO: Check whether a word is possible given the evidence. Return True if
    it is possible and False otherwise. Evidence is (pattern, incorrect_guesses):
    the five-character pattern uses uppercase letters and '-' for blanks, and
    the second string contains letters known to be absent. A correct guess
    reveals every occurrence, so a revealed letter cannot also be in a blank.

    For example, after guessing A, B, and C, evidence ('--A--', 'BC') is
    compatible with GRAPE but not DIGIT or CRATE.

    Parameters
    ----------
    evidence : tuple
        A tuple containing two strings.
    w : str
        Word to be checked.

    Returns
    -------
    bool
        True if its possible, False otherwise.
    """
    raise NotImplementedError("check_evidence function is not implemented.")

def compute_prior(word_counts: pd.DataFrame) -> pd.Series:
    """
    TODO: Compute the prior probabilities for all words in the corpus.

    Parameters
    ----------
    word_counts : pd.DataFrame
        DataFrame containing words and their counts.

    Returns
    -------
    pd.Series
        Prior probabilities for all words in the corpus.
    """
    raise NotImplementedError("compute_prior function is not implemented.")

def get_prior(word, word_counts):
    """
    TODO: Get the prior probability for a given word from the dataframe.
    
    Parameters
    ----------
    word : String
        The word to get prior probability for
    
    word_counts: pd.DataFrame
        DataFrame containing words and their counts
    
    Returns
    -------
    Float
        Prior probability for a given word.
    """
    raise NotImplementedError('get_prior function is not implemented.')

def compute_posterior_denominator(evidence: Tuple[str, str], word_counts: pd.DataFrame) -> float:
    """
    TODO: This function computes the denominator of the posterior probability.
    
    Note: this is done separately to speed up computation since this is the same regardless
    of the word.

    Parameters
    ----------
    evidence : tuple
        A tuple containing two strings.
    word_counts : pd.DataFrame
        DataFrame containing words, counts, and prior probabilities.

    Returns
    -------
    float
        Probability of evidence.
    """
    raise NotImplementedError("compute_posterior_denominator function is not implemented.")

def compute_posterior(evidence: Tuple[str, str], word: str, word_counts: pd.DataFrame, denominator: float) -> float:
    """
    TODO: This function computes the posterior probability used for determining the most likely
    character to predict from the unguessed pool. 
    
    Note: you should use compute_posterior_denominator to help compute this posterior probability.

    Parameters
    ----------
    evidence : tuple
        A tuple containing two strings.
    word : str
        A given word to compute posterior for.
    word_counts : pd.DataFrame
        DataFrame containing words, counts, and prior probabilities.
    denominator : float
        Denominator of the posterior probability computed earlier.

    Returns
    -------
    float
        Posterior probability.
    """
    raise NotImplementedError("compute_posterior function is not implemented.")

def predictive_probability(evidence: Tuple[str, str], word_counts: pd.DataFrame, denominator: float) -> list:
    """
    TODO: Compute the probability for each letter being in the word given the
    evidence. Return a list of 26 probabilities in A-to-Z order. Count a
    letter only once per word, even if it appears in multiple positions.

    Parameters
    ----------
    evidence : tuple
        A tuple containing two strings.
    word_counts : pd.DataFrame
        DataFrame containing words, counts, and prior probabilities.
    denominator : float
        Denominator of posterior probability.

    Returns
    -------
    list
        A list of probabilities for each letter.
    """
    raise NotImplementedError("predictive_probability function is not implemented.")

def predict_character(evidence: Tuple[str, str], word_counts: pd.DataFrame, denominator: float) -> Tuple[str, float]:
    """
    TODO: Generate the best previously unguessed letter and its predictive
    probability. If letters tie exactly, choose the alphabetically first one.

    Parameters
    ----------
    evidence : tuple
        A tuple containing two strings.
    word_counts : pd.DataFrame
        DataFrame containing words, counts, and prior probabilities.
    denominator : float
        Denominator of the posterior probability.

    Returns
    -------
    tuple
        Predicted character and associated probability.
    """
    raise NotImplementedError("predict_character function is not implemented.")

def run_hangman(word_counts: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """
    Helper function to run hangman on the given test examples. 
    
    Note: feel free to modify the test cases to more thoroughly 
    test your solution.

    Parameters
    ----------
    word_counts : pd.DataFrame
        pandas DataFrame containing corpus words, frequency, and prior probabilities.
    verbose : bool, optional
        Verbose set to True will print out the final dataframe table
        in a clean format. Defaults to True.

    Returns
    -------
    pd.DataFrame
        The final dataframe table.
    """
    empty_word = "-----"
    Evidence = [(empty_word, ""),
               (empty_word, "EA"),
                ("A---S", ""),
                ("A---S","I"),
                ("-E--E","AIMNT"),
                (empty_word,"EO"),
                ("D--I-",""),
                ("D--I-","A"),
                ("-U---","AEIOS")
               ]
    
    ### DO NOT MODIFY ###
    output = []
    for e in tqdm(Evidence, disable=not verbose):
        corr, incorr = e
        incorr = "{" + incorr + "}"
        char,prob = predict_character(e,word_counts,compute_posterior_denominator(e,word_counts))
        output += [(corr,incorr,char,prob)]
    
    output = pd.DataFrame(output,columns = ["Correctly Guessed", "Incorrectly Guessed","Character", "Probability"])
    if verbose:
        print((tabulate(output, headers='keys', tablefmt='psql')))
    return output

def process_data() -> pd.DataFrame:
    """
    This function processes the required file and returns a word_counts dataframe
    with three columns: Word, Count, Prior.
    
    Keep hw2_word_counts.txt next to this Python file, or in the current
    working directory used by the autograder.

    Returns
    -------
    pd.DataFrame
        The word_counts data table with columns ('Word', 'Count', 'Prior'), where each row
        represents a different word, its count, and the (computer) prior probability P(W=w)
        of that word. 
    """
    ### DO NOT MODIFY ###
    filename = 'hw2_word_counts.txt'
    candidates = [Path.cwd() / filename, Path(__file__).resolve().with_name(filename)]
    word_counts_path = next((path for path in candidates if path.is_file()), None)
    if word_counts_path is None:
        raise FileNotFoundError(f"Could not find {filename} in the working or script directory")

    word_counts = pd.read_csv(word_counts_path, header=None, sep=r'\s+', names=['Word', 'Count'])
    
    word_counts['Prior'] = compute_prior(word_counts)
    return word_counts
    
def run() -> Tuple[set, set, pd.DataFrame]:
    """
    TODO: This function should run all of hangman and return the required deliverables for parts A and B.

    Return three objects: two sets containing the 15 most and 14 least frequent
    5-letter words in the corpus (Part A), and a nine-row pandas DataFrame with
    the next best guess and its predictive probability for each Part B state.

    DO NOT MODIFY the return types of this function, as this is what the autograder will use to grade your homework!
    
    Returns
    -------
    Tuple[set, set, pd.DataFrame]
        The 15 most frequent 5-letter words (as a set), the 14 least frequent 5-letter words (as a set), and
        a pandas DataFrame containing the next best guess l and the associated predictive probability for 
        each test case.
    """
    word_counts = process_data()

    most_frequent_15 = ... # TODO
    least_frequent_14 = ... # TODO
    output = ... # TODO
    
    return set(most_frequent_15), set(least_frequent_14), output
    
if __name__ == "__main__":    
    run()
